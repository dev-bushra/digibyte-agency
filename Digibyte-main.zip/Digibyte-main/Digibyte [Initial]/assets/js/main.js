;
(function($) {
    'use strict'
 })(jQuery)